
  $('.btn').click(function () {
    $('.sprinkles').toggleClass('show');
  })
